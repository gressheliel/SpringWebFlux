package com.debuggeandoideas.eats_hub_catalog.exceptions;

public class BusinessException extends RuntimeException {

    public BusinessException(String message) {
        super(message);
    }
}
