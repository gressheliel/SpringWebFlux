package com.debuggeandoideas.eats_hub_catalog.records;

public record ContactInfo(
         String phone,
         String email,
         String website
){ }
