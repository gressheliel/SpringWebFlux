package com.debuggeandoideas.eats_hub_catalog.enums;

public enum PriceEnum {
    CHEAP, MEDIUM, EXPENSIVE;
}
