package com.debuggeandoideas.eats_hub_catalog.enums;

public enum ReservationStatusEnum {
    PENDING, CONFIRMED
}
