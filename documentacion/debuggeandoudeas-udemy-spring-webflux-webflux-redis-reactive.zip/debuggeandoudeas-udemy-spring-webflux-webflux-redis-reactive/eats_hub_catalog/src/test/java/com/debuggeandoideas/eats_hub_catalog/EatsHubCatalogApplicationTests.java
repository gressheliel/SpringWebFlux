package com.debuggeandoideas.eats_hub_catalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EatsHubCatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
